function [res]= ClusteringMeasure_mht(Y, preY)

[newIndx] = bestMap(Y,preY);
ACC = mean(Y==newIndx);
NMI = MutualInfo(Y,newIndx);
PUR = purFuc(Y,newIndx);

res = [ACC,NMI,PUR];
