function [res]= ComparedNMIACCwithmean_mht(U,Y,numclass)

maxIter = 50;
for iter = 1:maxIter
    indx = kmeans(U,numclass,'MaxIter',100, 'Replicates',1);
    [ress(iter,:)] = ClusteringMeasure(indx,Y);
end
res = [mean(ress(:,1)),mean(ress(:,2)),mean(ress(:,3)),std(ress(:,1)),std(ress(:,2)),std(ress(:,3))];
