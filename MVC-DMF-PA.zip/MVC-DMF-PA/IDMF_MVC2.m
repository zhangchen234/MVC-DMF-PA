function [HC,obj1,obj2,obj] = IDMF_MVC2( fea, layers, varargin )

pnames = {'z0' 'h0' 'bUpdateH' 'bUpdateLastH' 'maxiter' 'TolFun','verbose', 'bUpdateZ', 'cache', 'gnd', 'lambda', 'savePath'};
dflts  = {0, 0, 1, 1, 150, 1e-6, 0, 1, 0};
[z0, h0, bUpdateH, bUpdateLastH, maxiter, tolfun, verbose, bUpdateZ, cache, gnd, lambda] = internal.stats.parseArgs(pnames,dflts,varargin{:});

numOfView = numel(fea);
numOfLayer = numel(layers);
numOfSample = size(fea{1,1},2);
numOfCluster = length(unique(gnd));
X = cell(1,numOfView);

% each view should be initialized also.
% init Z and H
Z = cell(numOfView, numOfLayer);
H = cell(numOfView, numOfLayer);

% normalized
for v_ind = 1:numOfView
    X{v_ind} = fea{v_ind};
    ind = all(X{1,v_ind}==0,1);
    if sum(ind) == 0
        X{v_ind} = bsxfun(@rdivide,X{v_ind},sqrt(sum(X{v_ind}.^2,1)));
    end
end


for v_ind = 1:numOfView
    if  ~iscell(h0)
        for i_layer = 1:length(layers)
            if i_layer == 1
                % For the first layer we go linear from X to Z*H, so we use id
                V = X{v_ind};
            else
                V = H{v_ind,i_layer-1};
            end

            if verbose
                fprintf('Initialising Layer #%d with k=%d with size(V)=%s...\n', i_layer, layers(i_layer), mat2str(size(V)));
            end
            if ~iscell(z0)
                % For the later layers we use nonlinearities as we go from
                % g(H_{k-1}) to Z*H_k
                [Z{v_ind,i_layer}, H{v_ind,i_layer}, ~] = ...
                    seminmf(V, ...
                    layers(i_layer), ...
                    'maxiter', maxiter, ...
                    'bUpdateH', true, 'bUpdateZ', bUpdateZ, 'verbose', verbose, 'save', cache, 'fast', 1);
            else
                display('Using existing Z');
                [Z{v_ind,i_layer}, H{v_ind,i_layer}, ~] = ...
                    seminmf(V, ...
                    layers(i_layer), ...
                    'maxiter', 1, ...
                    'bUpdateH', true, 'bUpdateZ', 0, 'z0', z0{i_layer}, 'verbose', verbose, 'save', cache, 'fast', 1);
            end
        end
        else
            Z=z0;
            H=h0;
        if verbose
            display('Skipping initialization, using provided init matrices...');
        end
    end
end

% init alpha, beta and W
alpha = ones(numOfView,1).*(1/numOfView);
beta = ones(numOfView,1).*(1/numOfView);
W = cell(1,numOfView);
for v_ind = 1:numOfView
    W{1,v_ind} = eye(numOfCluster);
end

H_err = cell(numOfView, numOfLayer);
HC = zeros(numOfCluster,numOfSample);

%% fine tuning
% disp(fileName);
for iter = 1:maxiter
       
    % update HC
    U = zeros(numOfSample,numOfCluster);
    for v_ind = 1:numOfView
        U = U + beta(v_ind) * H{v_ind,numOfLayer}' * W{v_ind};
    end
    [Uh1,~,Vh1] = svd(U,'econ');
    HC = Vh1 * Uh1';

    % update Zi  Hi  Hm  
    for v_ind = 1:numOfView
        H_err{v_ind,numOfLayer} = H{v_ind,numOfLayer};
        for i_layer = numOfLayer-1:-1:1
            H_err{v_ind,i_layer} = Z{v_ind,i_layer+1} * H_err{v_ind,i_layer+1};
        end

        for i = 1:numOfLayer
            %update Zi
            if bUpdateZ
                try
                    if i == 1
                        Z{v_ind,i} = X{v_ind}  * pinv(H_err{v_ind,1});
                    else
                        Z{v_ind,i} = pinv(Dz) * X{v_ind} * pinv(H_err{v_ind,i});
                    end
                catch
        %                     display(sprintf('Convergance error %f. min Z{i}: %f. max %f', norm(Z{v_ind,i}, 'fro'), min(min(Z{v_ind,i})), max(max(Z{v_ind,i}))));
                end
            end
            if i == 1
                Dz = Z{v_ind,1};
            else
                Dz = Dz * Z{v_ind,i};
            end

            % update Hi
            if bUpdateH && (i < numOfLayer) || (i==numOfLayer) && bUpdateLastH          
                % DT*X -> DTX
                DTX =  Dz' * X{v_ind};
                DTXp = (abs(DTX)+DTX)./2;
                DTXn = (abs(DTX)-DTX)./2;

                % DT*D -> DTD
                DTD =  Dz' * Dz;
                DTDp = (abs(DTD)+DTD)./2;
                DTDn = (abs(DTD)-DTD)./2;

                H{v_ind,i} = H{v_ind,i} .* sqrt((DTXp + DTDn * H{v_ind,i}) ./ max(DTXn + DTDp * H{v_ind,i}, 1e-10));

                % update Hm
                if i == numOfLayer                    
                    % W*HC  ->  WHC
                    WHC = W{v_ind} * HC;
                    WHCp = (abs(WHC)+WHC)./2;
                    WHCn = (abs(WHC)-WHC)./2;

                    ZHSu =  2*alpha(v_ind)^2 * (DTXp + DTDn * H{v_ind,i}) + lambda * beta(v_ind) * WHCp;
                    ZHSd =  max((2*alpha(v_ind)^2 * (DTXn + DTDp * H{v_ind,i}) + lambda*beta(v_ind)*WHCn),1e-10);
                    H{v_ind,numOfLayer} = H{v_ind,numOfLayer} .* sqrt(ZHSu ./ ZHSd); 
                end
            end
        end
    end

    % update W
    for v_ind = 1:numOfView
        Q = beta(v_ind) * H{v_ind,numOfLayer} * HC';
        [Uh2,~,Vh2] = svd(Q,'econ');
        W{v_ind} = Uh2  * Vh2';
    end


    % update alpha
    Rs = zeros(numOfView,1);
    for v_ind = 1:numOfView
        Rs(v_ind,1) = norm(X{v_ind} - reconstruction(Z(v_ind,:), H(v_ind,:)), 'fro');
    end
    R_all = sum(Rs);
      
    for v_ind = 1:numOfView
        alpha(v_ind) = R_all/max(Rs(v_ind),1e-10);
    end
    alpha(alpha<1e-6)=0; 
    alpha = alpha/sum(alpha);

    % update beta
    f = zeros(numOfView,1);
    for v_ind = 1:numOfView
        f(v_ind) = -trace(H{v_ind,numOfLayer}' * W{v_ind} * HC);
    end

    beta = f/sum(f.^2);


    obj1(iter) = cost_nmf(X,Z,H,numOfView,alpha);
    obj2(iter) = cost_tr(beta,lambda,H,HC,W,numOfView,numOfLayer);
    obj(iter) = obj1(iter) + obj2(iter);
    
    if verbose
        fprintf('#%d error: %f\n', iter, obj(iter));
    end

    if (iter>2) && (abs((obj(iter-1)-obj(iter))/(obj(iter-1)))<tolfun)|| iter==maxiter
        break;
    end
end

end

% obj1(iter) = cost_nmf(X,Z,H,numOfView,alpha);
function [error] = cost_nmf(X,Z,H,numOfView,alpha)
    error = 0;
    for v_ind =1:numOfView
        error = error + alpha(v_ind)^2 * norm(X{v_ind} - reconstruction(Z(v_ind,:), H(v_ind,:)), 'fro');
    end
end

% obj2(iter) = cost_tr(beta,lambda,H,HC,W,numOfView,numOfLayer);
function [error] = cost_tr(beta,lambda,H,HC,W,numOfView,numOfLayer)
    temp =beta(1)*   H{1,numOfLayer}' * W{1};
    for v_ind =2:numOfView
        temp = temp + beta(v_ind)* H{v_ind,numOfLayer}' * W{v_ind};
    end
    error = -lambda * trace(HC*temp);
end


function [ out ] = reconstruction( Z, H )
    out = H{numel(H)};
    for k = numel(H) : -1 : 1
        out =  Z{k} * out;
    end
end