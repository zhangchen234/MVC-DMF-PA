addpath(genpath('.'));
clc;
clear;
warning off;

DataName{1} = 'bbcsport';

smallDatasets = [1];
LAMBDA = 2;

dataPath = './data/';
fprintf('------------twoLayers -----------\n');

for ICount=smallDatasets
    load([dataPath,DataName{ICount}],'X','Y')
    fprintf(' #-- dataset is: %s   -----\n',DataName{ICount});
    
    CluNum = length(unique(Y));
    fea = cell(1,length(X));
    for view =1:length(X)
        X{1,view} = double(full(X{1,view}));
        fea{1,view} = NormalizeFea(X{1,view}, 0);
    end
    
    lambda = 2.^4;
    layers = CluNum*[12,6,1];
    
    fprintf('     layer1=%d,   layer2=%d,   lambda=%d\n',layers(1)/CluNum,layers(2)/CluNum,log2(lambda));
    [Hstar]=IDMF_MVC2(fea, layers, 'gnd', Y,'lambda', lambda);
    res9 = myNMIACCwithmean(Hstar',Y,CluNum);
     fprintf('     ACC=%d,   NMI=%d,   PUR=%d\n',res9(1),res9(2),res9(3));    
end